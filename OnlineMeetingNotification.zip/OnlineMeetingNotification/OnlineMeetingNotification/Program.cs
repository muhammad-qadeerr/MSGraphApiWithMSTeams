﻿
using Microsoft.Graph;
using Microsoft.Identity.Client;
using System.Net.Http.Headers;
using Microsoft.Graph.Models;
using System.Net.Http;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Text;
using OnlineMeetingNotification.Model;

namespace OnlineMeetingNotification
{
    class Program
    {

        public static string TeamsTenantId = "fa2f0010-2e06-4c89-8f18-228da7bec8ac";
        public static string TeamsClientId = "e8e11828-b94b-434f-971c-747ae0d1d258";
        public static string TeamsClientSecret = "kxg8Q~gEtbKPI_OaNKBwWWLXylfx6KYYUWSGra91";
        public static string[] scopes = new[] { "https://graph.microsoft.com/.default" };

        //local
        //private const string apiUrl = "https://localhost:45100/mazapi/v1/values/msteam/meetingnotification?meetingId=testnabeel&meetingName=Amazing stories";
        
        //dev
        //private const string apiUrl = "https://dev-api.amazepbc.com/mazapi/v1/values/msteam/meetingnotification?";

        //stage
        //private const string apiUrl = "https://stg-api.amazepbc.com/mazapi/v1/values/msteam/meetingnotification?";

        //prod
        private const string apiUrl = "https://api.amazepbc.com/mazapi/v1/values/msteam/meetingnotification?";


        static async Task Main(string[] args)
        {
            List<MeetingModel> meetings = FeedMeetingData();
            // Initialize the confidential client application
            IConfidentialClientApplication app = ConfidentialClientApplicationBuilder.Create(TeamsClientId)
                .WithClientSecret(TeamsClientSecret)
                .WithAuthority(new Uri($"https://login.microsoftonline.com/{TeamsTenantId}"))
                .Build();

            // Acquire the token
            var result = await app.AcquireTokenForClient(scopes).ExecuteAsync();
            string accessToken = result.AccessToken;

            // Initialize HttpClient with the token
            HttpClient httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            // Initialize GraphServiceClient with the HttpClient
            GraphServiceClient graphClient = new GraphServiceClient(httpClient);

            StringBuilder stringBuilder = new StringBuilder();
            foreach (var meeting in meetings)
            {
                string encodedUrl = System.Net.WebUtility.UrlEncode(meeting.MeetingTeamLink);
                string notificationurl = apiUrl + "meetingId=" +meeting.MeetingId+"&meetingName="+meeting.MeetingName;
                try
                {
                    var subscription = new Subscription
                    {
                        ChangeType = "created,updated",
                        NotificationUrl = notificationurl,
                        Resource = $"/communications/onlineMeetings/?$filter=JoinWebUrl eq '{encodedUrl}'",
                        ExpirationDateTime = DateTime.UtcNow.AddMinutes(1435),
                        ClientState = "SecretClientState",
                    };

                    var newSubscription = await graphClient.Subscriptions.PostAsync(subscription);
                    Console.WriteLine($"{DateTime.Now} Subscription Create from {notificationurl} and subscription id is {newSubscription?.Id} ");
                    stringBuilder.AppendLine($"{DateTime.Now} Subscription Created from {notificationurl} and subscription id is {newSubscription?.Id} ");
                }
                catch (Exception ex)
                {
                    //send mail
                    Console.WriteLine($"{DateTime.Now} Subscription not Created for {notificationurl} and exception is " + ex.ToString());
                    stringBuilder.AppendLine($"{DateTime.Now} Subscription not Created for {notificationurl} and exception is " + ex.ToString());
                }
            }
            await sendEmail(stringBuilder.ToString());

            Console.WriteLine($"{DateTime.Now} ==HELOOOOOO==");
        }
        private static async Task sendEmail(string body)
        {

            var client = new SendGridClient("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");
            var msg = new SendGridMessage()
            {
                From = new SendGrid.Helpers.Mail.EmailAddress("faisal.ghaffar@amazehealth.com", "Team Subsctiption Notification"),
                Subject = "Team Subsctiption Notification",
                HtmlContent = body
            };
            msg.AddTo("nabeel.iqbal@amazehealth.com");
            msg.AddCc("ali.zaheer@amazehealth.com");
            msg.SetClickTracking(false, false);

            _ = await client.SendEmailAsync(msg);

        }
        private static List<MeetingModel> FeedMeetingData()
        {
            List<MeetingModel> meetingModels = new List<MeetingModel>();
            meetingModels.Add(new MeetingModel { MeetingId = "staffmeeting", MeetingName = "All Staff Meeting", MeetingTeamLink = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_NTY3MmU5ODQtYzA1Mi00Yjg1LWI2NzctN2QxODdhYzQ3NjE5%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22360de8d5-e1ac-4b4e-a0a9-0809ba5fab41%22%7d" });
            meetingModels.Add(new MeetingModel { MeetingId = "managementmeeting", MeetingName = "Management Meeting", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_YzQ5MDIyNmItYzlmYy00MzkyLWJiOTItZTU3OWExYzA3MGFm%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%226f14c24f-92ab-407d-8224-9f541c561ac7%22%7d" });
            meetingModels.Add(new MeetingModel { MeetingId = "medicalteammeeting", MeetingName = "Medical Team Meeting", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_NjU4OGNlMDUtYjlhYS00Yzg4LWJjMTgtNTg0NzE2NDRjODYw%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22a0bad9b1-895c-480a-8d28-6b154fcc5a49%22%7d" });
            meetingModels.Add(new MeetingModel { MeetingId = "teamchatweeklymeeting", MeetingName = "A Team Chat & Weekly Meeting", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZjIzMDc1MTQtMjJkYi00OWE5LWE5MDYtODk0OGFhYzc5OTgx%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22bf454659-d985-4d4c-8d1c-c24c3f1194b0%22%7d" });
            meetingModels.Add(new MeetingModel { MeetingId = "mentalhealthmeetings1", MeetingName = "Mental health Meetings 1", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_ODliYWM2NzUtZDJiYi00Zjg0LWFjOGItNzUwODA2MmIzYjRj%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22d530775d-2dc6-44b3-af2e-026c5caf20b8%22%7d" });
            meetingModels.Add(new MeetingModel { MeetingId = "mentalhealthmeetings2", MeetingName = "Mental health Meetings 2", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_OGM1MTI2MjAtZWMwNy00N2NkLWE1ZWYtYzdkYWY0YzE4ZGMy%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22d530775d-2dc6-44b3-af2e-026c5caf20b8%22%7d" });
            meetingModels.Add(new MeetingModel { MeetingId = "amazingstoriesteammeeting", MeetingName = "Amazing Stories", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZmMzMmVkODEtZDIyMC00OWZiLWIzYjctYWZkNTZiY2QwMWFj%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%226f14c24f-92ab-407d-8224-9f541c561ac7%22%7d" });
            meetingModels.Add(new MeetingModel { MeetingId = "ccmmeeting", MeetingName = "CCM Meeting", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_YjNkYzMyZDEtNDcwZS00NGI4LWFmMjMtYTE4ODNiOWI0YjY4%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%228037b27a-58c7-4b30-ad53-7d5b42af1cb1%22%7d" });


            return meetingModels;

            //     //live meeting url
            //public const string staffmeeting = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_NTY3MmU5ODQtYzA1Mi00Yjg1LWI2NzctN2QxODdhYzQ3NjE5%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22360de8d5-e1ac-4b4e-a0a9-0809ba5fab41%22%7d";
            //public const string managementmeeting = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_YzQ5MDIyNmItYzlmYy00MzkyLWJiOTItZTU3OWExYzA3MGFm%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%226f14c24f-92ab-407d-8224-9f541c561ac7%22%7d";
            //public const string medicalteammeeting = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_NjU4OGNlMDUtYjlhYS00Yzg4LWJjMTgtNTg0NzE2NDRjODYw%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22a0bad9b1-895c-480a-8d28-6b154fcc5a49%22%7d";
            ////A Team Chat & Weekly Meeting
            //public const string patientadvocateteammeeting = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZjIzMDc1MTQtMjJkYi00OWE5LWE5MDYtODk0OGFhYzc5OTgx%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22bf454659-d985-4d4c-8d1c-c24c3f1194b0%22%7d";
            ////mental health meeting 1
            //public const string mentalhealthteammeeting = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_ODliYWM2NzUtZDJiYi00Zjg0LWFjOGItNzUwODA2MmIzYjRj%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22d530775d-2dc6-44b3-af2e-026c5caf20b8%22%7d";
            ////mental health meeting 2
            //public const string mentalhealthteammeeting2 = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_OGM1MTI2MjAtZWMwNy00N2NkLWE1ZWYtYzdkYWY0YzE4ZGMy%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22d530775d-2dc6-44b3-af2e-026c5caf20b8%22%7d";
            //public const string amazingstoriesteammeeting = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZmMzMmVkODEtZDIyMC00OWZiLWIzYjctYWZkNTZiY2QwMWFj%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%226f14c24f-92ab-407d-8224-9f541c561ac7%22%7d";
            //public const string ccmteammeeting = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_YjNkYzMyZDEtNDcwZS00NGI4LWFmMjMtYTE4ODNiOWI0YjY4%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%228037b27a-58c7-4b30-ad53-7d5b42af1cb1%22%7d";


            //Test meeting url
            //public static string staffmeeting = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_OWZjM2RkODUtOTJlZS00MDQ3LTkyZmYtMjg4Y2E0OGNkMjQy%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%223db8b5fb-512c-402c-9358-337229f320ae%22%7d";
            //public static string managementmeeting = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_Y2IzMmQwOGEtZTRiNC00ZGQ5LWFhMzMtZmNhNTk1NWNmYmFi%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%229c001153-ab58-4591-a81f-b722d67b98ee%22%7d";
            //public static string medicalteammeeting = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_MmJmODJkZmItY2JhOC00ZWRjLTk1ZTgtM2UxOGY2MThmNGFj%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%229c001153-ab58-4591-a81f-b722d67b98ee%22%7d";
            //public static string patientadvocateteammeeting = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_YTAyMDIxNGItNzk1OC00MjBhLTljM2EtNzYwYjNjZWYwMjg0%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%229c001153-ab58-4591-a81f-b722d67b98ee%22%7d";
            //public static string mentalhealthteammeeting = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_YTAyMDIxNGItNzk1OC00MjBhLTljM2EtNzYwYjNjZWYwMjg0%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%229c001153-ab58-4591-a81f-b722d67b98ee%22%7d";

        }
    }

}