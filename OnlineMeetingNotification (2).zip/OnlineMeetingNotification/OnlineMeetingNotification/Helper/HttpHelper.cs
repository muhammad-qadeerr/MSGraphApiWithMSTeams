﻿using Newtonsoft.Json;
using OnlineMeetingNotification.Types;
using System.Text;

namespace OnlineMeetingNotification.Helper
{
    public class HttpHelper
    {
        private readonly HttpClient _client;
        public HttpHelper(HttpClient client)
        {
            _client = client ?? throw new ArgumentNullException(nameof(client));
        }
        public static string getFullURI(string uri, HostedEnvironment environment, bool isV2 = false)
        {
            return NotificationAPIURLHelper.GetHostedApiEnvironment(environment) + "/mazapi/" + (isV2 ? "v2/" : "v1/") + uri;
        }

        // Generic GET method
        public async Task<T> GetAsync<T>(string uri, HostedEnvironment environment, bool isV2 = false)
        {
            if (string.IsNullOrEmpty(uri))
            {
                throw new ArgumentException("URI cannot be null or empty.", nameof(uri));
            }
            HttpResponseMessage response;

            try
            {
                _client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", TokenHelper.GenerateClientAuthToken(NotificationAPIURLHelper.GetHostedAuthEnvironment(HostedEnvironment.Development)));
                response = await _client.GetAsync($"{getFullURI(uri, environment, isV2)}");
            }
            catch (Exception ex)
            {
                throw new HttpRequestException("Error occurred while sending the HTTP request.", ex);
            }

            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException($"Request failed with status code: {response.StatusCode} - {response.ReasonPhrase}");
            }

            string jsonResponse = await response.Content.ReadAsStringAsync();
            if (string.IsNullOrWhiteSpace(jsonResponse))
            {
                throw new InvalidOperationException("Response content is empty or null.");
            }

            try
            {
                T? result = JsonConvert.DeserializeObject<T>(jsonResponse);
                if (result == null)
                {
                    throw new InvalidOperationException("Deserialization resulted in a null object.");
                }

                return result;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to deserialize the response content.", ex);
            }
        }

        // Generic POST method
        public async Task<T> PostAsync<T>(string uri, object content, HostedEnvironment environment, bool isV2 = false)
        {
            if (string.IsNullOrEmpty(uri))
            {
                throw new ArgumentException("URI cannot be null or empty.", nameof(uri));
            }


            string jsonContent = JsonConvert.SerializeObject(content);
            StringContent httpContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            HttpResponseMessage response;

            try
            {
                response = await _client.PostAsync($"{getFullURI(uri, environment, isV2)}", httpContent);
            }
            catch (Exception ex)
            {
                throw new HttpRequestException("Error occurred while sending the HTTP request.", ex);
            }

            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException($"Request failed with status code: {response.StatusCode} - {response.ReasonPhrase}");
            }

            string jsonResponse = await response.Content.ReadAsStringAsync();
            if (string.IsNullOrWhiteSpace(jsonResponse))
            {
                throw new InvalidOperationException("Response content is empty or null.");
            }

            try
            {
                T? result = JsonConvert.DeserializeObject<T>(jsonResponse);
                if (result is null)
                {
                    throw new InvalidOperationException("Deserialization resulted in a null object.");
                }

                return result;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to deserialize the response content.", ex);
            }
        }

        // Generic PUT method
        public async Task<T> PutAsync<T>(string uri, object content, HostedEnvironment environment, bool isV2 = false)
        {
            if (string.IsNullOrEmpty(uri))
            {
                throw new ArgumentException("URI cannot be null or empty.", nameof(uri));
            }


            string jsonContent = JsonConvert.SerializeObject(content);
            StringContent httpContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            HttpResponseMessage response;

            try
            {
                response = await _client.PutAsync($"{getFullURI(uri, environment, isV2)}", httpContent);
            }
            catch (Exception ex)
            {
                throw new HttpRequestException("Error occurred while sending the HTTP request.", ex);
            }

            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException($"Request failed with status code: {response.StatusCode} - {response.ReasonPhrase}");
            }

            string jsonResponse = await response.Content.ReadAsStringAsync();
            if (string.IsNullOrWhiteSpace(jsonResponse))
            {
                throw new InvalidOperationException("Response content is empty or null.");
            }

            try
            {
                T? result = JsonConvert.DeserializeObject<T>(jsonResponse);
                if (result is null)
                {
                    throw new InvalidOperationException("Deserialization resulted in a null object.");
                }

                return result;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to deserialize the response content.", ex);
            }
        }

        // Generic DELETE method
        public async Task DeleteAsync(string uri, HostedEnvironment environment, bool isV2 = false)
        {
            if (string.IsNullOrEmpty(uri))
            {
                throw new ArgumentException("URI cannot be null or empty.", nameof(uri));
            }
            HttpResponseMessage response;

            try
            {
                response = await _client.DeleteAsync($"{getFullURI(uri, environment, isV2)}");
            }
            catch (Exception ex)
            {
                throw new HttpRequestException("Error occurred while sending the HTTP request.", ex);
            }

            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException($"Request failed with status code: {response.StatusCode} - {response.ReasonPhrase}");
            }
        }

    }
}
