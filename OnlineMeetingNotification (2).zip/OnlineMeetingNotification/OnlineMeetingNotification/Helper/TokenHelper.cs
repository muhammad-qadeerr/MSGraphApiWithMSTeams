﻿using IdentityModel.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineMeetingNotification.Helper
{
    public static class TokenHelper
    {
        public static string GenerateClientAuthToken(string authUrl)
        {
            try
            {
                Console.WriteLine($"{DateTime.Now} GenerateClientAuthToken");
                string clientAuthToken = string.Empty;
                using (var client = new HttpClient())
                {
                    DiscoveryDocumentResponse disco = client.GetDiscoveryDocumentAsync(authUrl).Result;

                    if (!disco.IsError)
                    {
                        var tokenResponse = client.RequestClientCredentialsTokenAsync(new ClientCredentialsTokenRequest
                        {
                            Address = disco.TokenEndpoint,
                            ClientId = "AmazeClient",
                            ClientSecret = "77D2764A2BD24DF9844F44C747E7E1E4MC"
                        }).Result;
                        clientAuthToken = tokenResponse.AccessToken;
                        Console.WriteLine($"{DateTime.Now} AuthToken Generated");
                    }
                }

                return clientAuthToken;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{DateTime.Now}" + ex.Message);
                throw ex;
            }
        }
    }
}
