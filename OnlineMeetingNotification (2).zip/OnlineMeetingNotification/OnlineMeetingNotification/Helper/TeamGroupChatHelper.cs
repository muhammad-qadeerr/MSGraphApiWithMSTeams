﻿using OnlineMeetingNotification.Types;

namespace OnlineMeetingNotification.Helper
{
    public static class TeamGroupChatHelper
    {
        public static string GetTeamGroupChatId(HostedEnvironment environment)
        {
            switch (environment)
            {
                case HostedEnvironment.Local:
                    return "19:8178c9a5a75e462d9ce9a238da33e334@thread.v2";
                case HostedEnvironment.Development:
                    return "19:8178c9a5a75e462d9ce9a238da33e334@thread.v2";
                case HostedEnvironment.Staging:
                    return "19:8178c9a5a75e462d9ce9a238da33e334@thread.v2";
                case HostedEnvironment.Production:
                    return "19:8178c9a5a75e462d9ce9a238da33e334@thread.v2";
                default:
                    return string.Empty;
            }
        }
    }
}
