﻿
using OnlineMeetingNotification.Types;

namespace OnlineMeetingNotification.Helper
{
    public class NotificationAPIURLHelper
    {
        public static string GetTeamMeetingNotificationURLs(HostedEnvironment environment)
        {
            switch (environment)
            {
                case HostedEnvironment.Local:
                    return "https://localhost:45100/mazapi/v1/values/msteam/meetingnotification?";
                case HostedEnvironment.Development:
                    return "https://dev-api.amazepbc.com/mazapi/v1/values/msteam/meetingnotification?";
                case HostedEnvironment.Staging:
                    return "https://stg-api.amazepbc.com/mazapi/v1/values/msteam/meetingnotification?";
                case HostedEnvironment.Production:
                    return "https://api.amazepbc.com/mazapi/v1/values/msteam/meetingnotification?";
                default:
                    return string.Empty;
            }
        }

        public static string GetTeamMessageNotificationURLs(HostedEnvironment environment)
        {
            switch (environment)
            {
                case HostedEnvironment.Local:
                    return "https://localhost:45100/mazapi/v1/values/msteam/groupnotification";
                case HostedEnvironment.Development:
                    return "https://dev-api.amazepbc.com/mazapi/v1/values/msteam/groupnotification";
                case HostedEnvironment.Staging:
                    return "https://stg-api.amazepbc.com/mazapi/v1/values/msteam/groupnotification";
                case HostedEnvironment.Production:
                    return "https://api.amazepbc.com/mazapi/v1/values/msteam/groupnotification";
                default:
                    return string.Empty;
            }
        }

        public static string GetTeamCallNotificationURLs(HostedEnvironment environment)
        {
            switch (environment)
            {
                case HostedEnvironment.Local:
                    return "https://localhost:45100/mazapi/v1/values/msteam/groupnotification";
                case HostedEnvironment.Development:
                    return "https://dev-api.amazepbc.com/mazapi/v1/values/msteam/groupnotification";
                case HostedEnvironment.Staging:
                    return "https://stg-api.amazepbc.com/mazapi/v1/values/msteam/groupnotification";
                case HostedEnvironment.Production:
                    return "https://api.amazepbc.com/mazapi/v1/values/msteam/groupnotification";
                default:
                    return string.Empty;
            }
        }

        public static string GetHostedAuthEnvironment(HostedEnvironment environment)
        {
            switch (environment)
            {
                case HostedEnvironment.Local:
                    return "https://localhost:5000";
                case HostedEnvironment.Development:
                    return "https://dev-auth.amazepbc.com";
                case HostedEnvironment.Staging:
                    return "https://stg-auth.amazepbc.com";
                case HostedEnvironment.Production:
                    return "https://auth.amazepbc.com";
                default:
                    return string.Empty;
            }
        }

        public static string GetHostedApiEnvironment(HostedEnvironment environment)
        {
            switch (environment)
            {
                case HostedEnvironment.Local:
                    return "https://localhost:45100";
                case HostedEnvironment.Development:
                    return "https://dev-api.amazepbc.com";
                case HostedEnvironment.Staging:
                    return "https://stg-api.amazepbc.com";
                case HostedEnvironment.Production:
                    return "https://api.amazepbc.com";
                default:
                    return string.Empty;
            }
        }
    }
}
