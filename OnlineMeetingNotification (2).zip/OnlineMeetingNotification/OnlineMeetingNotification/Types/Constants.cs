﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineMeetingNotification.Types
{
    public class Constant
    {
        public const string TeamsTenantId = "fa2f0010-2e06-4c89-8f18-228da7bec8ac";
        public const string TeamsClientId = "e2f82ba1-63cb-4680-a8f5-5459c6ec7c9d";//"e8e11828-b94b-434f-971c-747ae0d1d258";
        public const string TeamsClientSecret = "_hZ8Q~BqSOBj57evcTB_yIfwQQzmH8H.~0DkHaSI";//"kxg8Q~gEtbKPI_OaNKBwWWLXylfx6KYYUWSGra91";
        public static string[] Scopes = new[] { "https://graph.microsoft.com/.default" };
    }
}
