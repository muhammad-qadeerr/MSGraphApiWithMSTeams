﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineMeetingNotification.Types
{
    public enum HostedEnvironment { Local = 1, Development = 2, Staging = 3, Production = 4 }
    public enum SubscriptionType { TeamMeeting = 1, GroupChat = 2 }

}
