﻿using OnlineMeetingNotification.Model;

namespace OnlineMeetingNotification.Types
{
    public static class BaseData
    {
        public static List<MeetingModel> GetMeetingData(HostedEnvironment environment)
        {
            List<MeetingModel> meetingModels = new List<MeetingModel>();
            if (environment == HostedEnvironment.Production)
            {
                meetingModels.Add(new MeetingModel { MeetingId = "staffmeeting", MeetingName = "All Staff Meeting", MeetingTeamLink = @"https://teams.microsoft.com/l/meetup-join/19%3ameeting_NTY3MmU5ODQtYzA1Mi00Yjg1LWI2NzctN2QxODdhYzQ3NjE5%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22360de8d5-e1ac-4b4e-a0a9-0809ba5fab41%22%7d" });
                meetingModels.Add(new MeetingModel { MeetingId = "managementmeeting", MeetingName = "Management Meeting", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_YzQ5MDIyNmItYzlmYy00MzkyLWJiOTItZTU3OWExYzA3MGFm%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%226f14c24f-92ab-407d-8224-9f541c561ac7%22%7d" });
                meetingModels.Add(new MeetingModel { MeetingId = "medicalteammeeting", MeetingName = "Medical Team Meeting", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_NjU4OGNlMDUtYjlhYS00Yzg4LWJjMTgtNTg0NzE2NDRjODYw%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22a0bad9b1-895c-480a-8d28-6b154fcc5a49%22%7d" });
                meetingModels.Add(new MeetingModel { MeetingId = "teamchatweeklymeeting", MeetingName = "A Team Chat & Weekly Meeting", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZjIzMDc1MTQtMjJkYi00OWE5LWE5MDYtODk0OGFhYzc5OTgx%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22bf454659-d985-4d4c-8d1c-c24c3f1194b0%22%7d" });
                meetingModels.Add(new MeetingModel { MeetingId = "mentalhealthmeetings1", MeetingName = "Mental health Meetings 1", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_ODliYWM2NzUtZDJiYi00Zjg0LWFjOGItNzUwODA2MmIzYjRj%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22d530775d-2dc6-44b3-af2e-026c5caf20b8%22%7d" });
                meetingModels.Add(new MeetingModel { MeetingId = "mentalhealthmeetings2", MeetingName = "Mental health Meetings 2", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_OGM1MTI2MjAtZWMwNy00N2NkLWE1ZWYtYzdkYWY0YzE4ZGMy%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%22d530775d-2dc6-44b3-af2e-026c5caf20b8%22%7d" });
                meetingModels.Add(new MeetingModel { MeetingId = "amazingstoriesteammeeting", MeetingName = "Amazing Stories", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZmMzMmVkODEtZDIyMC00OWZiLWIzYjctYWZkNTZiY2QwMWFj%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%226f14c24f-92ab-407d-8224-9f541c561ac7%22%7d" });
                meetingModels.Add(new MeetingModel { MeetingId = "ccmmeeting", MeetingName = "CCM Meeting", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_YjNkYzMyZDEtNDcwZS00NGI4LWFmMjMtYTE4ODNiOWI0YjY4%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%228037b27a-58c7-4b30-ad53-7d5b42af1cb1%22%7d" });
            }
            else
            {
                meetingModels.Add(new MeetingModel { MeetingId = "ccmmeeting", MeetingName = "CCM Meeting", MeetingTeamLink = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZWVhMWYyNzEtODI1ZC00YTI0LTlmNzctMzNiNGZmYWJiYTAz%40thread.v2/0?context=%7b%22Tid%22%3a%22fa2f0010-2e06-4c89-8f18-228da7bec8ac%22%2c%22Oid%22%3a%223db8b5fb-512c-402c-9358-337229f320ae%22%7d" });
            }
            return meetingModels;
        }

        public static List<string> GetTeamGroupChatIdData(HostedEnvironment environment)
        {
            List<string> groupChatIds = new List<string>();
            if (environment == HostedEnvironment.Production)
            {
                groupChatIds.Add("");
            }
            if (environment == HostedEnvironment.Staging)
            {
                groupChatIds.Add("");
            }
            if (environment == HostedEnvironment.Development || environment == HostedEnvironment.Local)
            {
                groupChatIds.Add("19:8178c9a5a75e462d9ce9a238da33e334@thread.v2");
            }
            return groupChatIds;
        }
    }
}
