﻿
namespace OnlineMeetingNotification.Model
{
    public class MeetingModel
    {
        public string MeetingId { get; set; }
        public string MeetingTeamLink { get; set; }
        public string MeetingName { get; set; }

    }
}
