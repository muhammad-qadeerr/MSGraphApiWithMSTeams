﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineMeetingNotification.Model
{
    public class ChangeNotificationSubscriptionModel
    {
        public int Id { get; set; }
        public string SubscriptionId { get; set; }
        public string SubscriptionURL { get; set; }
        public string MeetingUrl { get; set; }
        public string GroupId { get; set; }
        public bool Status { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime ReNewAt { get; set; }
        public int SubscriptionType { get; set; }
    }
}
