﻿
using Microsoft.Graph;
using Microsoft.Identity.Client;
using System.Net.Http.Headers;
using Microsoft.Graph.Models;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Text;
using OnlineMeetingNotification.Model;
using OnlineMeetingNotification.Types;
using OnlineMeetingNotification.Helper;

namespace OnlineMeetingNotification
{
    class Program
    {
        static async Task Main(string[] args)
        {
            HostedEnvironment hostedEnvironment = HostedEnvironment.Development;

            //var res = await getSusbscriptions(hostedEnvironment);
            //List<MeetingModel> meetings = BaseData.GetMeetingData(hostedEnvironment);
            //List<string> teamGroupChats = BaseData.GetTeamGroupChatIdData(hostedEnvironment);

            string authurl = NotificationAPIURLHelper.GetHostedAuthEnvironment(hostedEnvironment);

            //string apiAccessToken = TokenHelper.GenerateClientAuthToken(authurl);

            // Initialize the confidential client application
            string accessToken = await GetAccessToken();
            GraphServiceClient graphClient = getGraphServiceClient(accessToken);
            string apiMeetingNotificationUrl = NotificationAPIURLHelper.GetTeamMeetingNotificationURLs(hostedEnvironment);
            string apiMessageNotificationUrl = NotificationAPIURLHelper.GetTeamMessageNotificationURLs(hostedEnvironment);
            string apiCallNotificationUrl = NotificationAPIURLHelper.GetTeamCallNotificationURLs(hostedEnvironment);
            await CreateTeamCallSubscriptions(graphClient, apiCallNotificationUrl);
            //await CreateMeetingSubscriptions(meetings, graphClient, apiMeetingNotificationUrl);
            //await CreateTeamGroupChatSubscriptions(teamGroupChats, graphClient, apiMessageNotificationUrl);
        }

        private static async Task<List<ChangeNotificationSubscriptionModel>> getSusbscriptions(HostedEnvironment environment)
        {
            HttpHelper client = new HttpHelper(new HttpClient());
            var res = await client.GetAsync<List<ChangeNotificationSubscriptionModel>>("values/msteam/subscription", environment);
            Console.WriteLine(res);
            return res;
        }

        private static async Task CreateMeetingSubscriptions(List<MeetingModel> meetings, GraphServiceClient graphClient, string apiMeetingNotificationUrl)
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var meeting in meetings)
            {
                string encodedUrl = System.Net.WebUtility.UrlEncode(meeting.MeetingTeamLink);
                string notificationurl = apiMeetingNotificationUrl + "meetingId=" + meeting.MeetingId + "&meetingName=" + meeting.MeetingName;
                try
                {
                    var subscription = new Subscription
                    {
                        ChangeType = "created,updated",
                        NotificationUrl = notificationurl,
                        Resource = $"/communications/onlineMeetings/?$filter=JoinWebUrl eq '{encodedUrl}'",
                        ExpirationDateTime = DateTime.UtcNow.AddMinutes(1435),
                        ClientState = "SecretClientState",
                    };

                    var newSubscription = await graphClient.Subscriptions.PostAsync(subscription);
                    Console.WriteLine($"{DateTime.Now} Subscription Create from {notificationurl} and subscription id is {newSubscription?.Id} ");
                    stringBuilder.AppendLine($"{DateTime.Now} Subscription Created from {notificationurl} and subscription id is {newSubscription?.Id} ");
                }
                catch (Exception ex)
                {
                    //send mail
                    Console.WriteLine($"{DateTime.Now} Subscription not Created for {notificationurl} and exception is " + ex.ToString());
                    stringBuilder.AppendLine($"{DateTime.Now} Subscription not Created for {notificationurl} and exception is " + ex.ToString());
                }
            }
            await sendEmail(stringBuilder.ToString(), "Team Subsctiption Notification");

            Console.WriteLine($"{DateTime.Now} ==HELOOOOOO==");
        }

        private static async Task CreateTeamGroupChatSubscriptions(List<string> teamGroupChats, GraphServiceClient graphClient, string apiTeamGroupChatNotificationUrl)
        {
            StringBuilder stringBuilder = new StringBuilder();
            string groupChatId = string.Empty;
            try
            {
                foreach (var item in teamGroupChats)
                {
                    groupChatId = item;
                    var subscription = new Subscription
                    {
                        ChangeType = "created,updated",
                        NotificationUrl = apiTeamGroupChatNotificationUrl,
                        Resource = $"/chats/{item}/messages",
                        ExpirationDateTime = DateTime.UtcNow.AddMinutes(1435),
                        ClientState = "SecretClientState",
                    };

                    var newSubscription = await graphClient.Subscriptions.PostAsync(subscription);
                    Console.WriteLine($"{DateTime.Now} Subscription Create from {item} and subscription id is {newSubscription?.Id} ");
                    stringBuilder.AppendLine($"{DateTime.Now} Subscription Created from {item} and subscription id is {newSubscription?.Id} ");
                }
            }
            catch (Exception ex)
            {
                //send mail
                Console.WriteLine($"{DateTime.Now} Subscription not Created for {groupChatId} and exception is " + ex.ToString());
                stringBuilder.AppendLine($"{DateTime.Now} Subscription not Created for {groupChatId} and exception is " + ex.ToString());
            }

            await sendEmail(stringBuilder.ToString(), "Team Group Chat Message Notification");

            Console.WriteLine($"{DateTime.Now} ==HELOOOOOO==");
        }

        private static async Task CreateTeamCallSubscriptions(GraphServiceClient graphClient, string apiTeamGroupChatNotificationUrl)
        {
            StringBuilder stringBuilder = new StringBuilder();
            try
            {
                var subscription = new Subscription
                {
                    ChangeType = "created,updated",
                    NotificationUrl = apiTeamGroupChatNotificationUrl,
                    Resource = $"/communications/calls",
                    ExpirationDateTime = DateTime.UtcNow.AddMinutes(10),
                    ClientState = "SecretClientState",
                };

                var newSubscription = await graphClient.Subscriptions.PostAsync(subscription);
                Console.WriteLine($"{DateTime.Now} Subscription Create from  and subscription id is {newSubscription?.Id} ");
                stringBuilder.AppendLine($"{DateTime.Now} Subscription Created from  and subscription id is {newSubscription?.Id} ");
            }
            catch (Exception ex)
            {
                //send mail
                Console.WriteLine($"{DateTime.Now} Subscription not Created for and exception is " + ex.ToString());
                stringBuilder.AppendLine($"{DateTime.Now} Subscription not Created for and exception is " + ex.ToString());
            }

            await sendEmail(stringBuilder.ToString(), "Team Group Chat Message Notification");

            Console.WriteLine($"{DateTime.Now} ==HELOOOOOO==");
        }

        public static async Task<string> GetAccessToken()
        {
            try
            {
                IConfidentialClientApplication app = ConfidentialClientApplicationBuilder.Create(Constant.TeamsClientId)
                  .WithClientSecret(Constant.TeamsClientSecret)
                  .WithAuthority(new Uri($"https://login.microsoftonline.com/{Constant.TeamsTenantId}"))
                  .Build();

                // Acquire the token
                var result = await app.AcquireTokenForClient(Constant.Scopes).ExecuteAsync();
                return result.AccessToken;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public static GraphServiceClient getGraphServiceClient(string acessToken)
        {
            // Initialize HttpClient with the token
            HttpClient httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", acessToken);

            // Initialize GraphServiceClient with the HttpClient
            GraphServiceClient graphClient = new GraphServiceClient(httpClient);
            return graphClient;
        }


        private static async Task sendEmail(string body, string subject)
        {

            var client = new SendGridClient("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");
            var msg = new SendGridMessage()
            {
                From = new SendGrid.Helpers.Mail.EmailAddress("faisal.ghaffar@amazehealth.com", subject),
                Subject = subject,
                HtmlContent = body
            };
            msg.AddTo("nabeel.iqbal@amazehealth.com");
            msg.AddCc("ali.zaheer@amazehealth.com");
            msg.SetClickTracking(false, false);

            _ = await client.SendEmailAsync(msg);

        }

    }

}